from ultralytics import YOLO

#model = YOLO("datasets/yolov8n/train15/weights/best.pt")
#model = YOLO("datasets/yolov8n-GhostNetV1-2/train2/weights/best.pt")
#model = YOLO("datasets/yolov8n-MobileNetV3/train3/weights/best.pt")
#model = YOLO("datasets/yolov8n-ShuffleNetV2-SlimNeck/train62/weights/best.pt")
#model = YOLO("datasets/yolov8n-ShuffleNetV2-SlimNeck/train74/weights/best.pt")

# Export the model
#model.export(format='engine',imgsz=(512,288))  # creates 'yolov8n.engine'
#model.export(format='engine',imgsz=(512,384))  # creates 'yolov8n.engine'
#model.export(format='engine',imgsz=(512,512))  # creates 'yolov8n.engine'

# Load the exported TensorRT model
#trt_model = YOLO('datasets/yolov8n/train15/weights/512best.engine')
#trt_model = YOLO('datasets/yolov8n-GhostNetV1-2/train2/weights/512best.engine')
#trt_model = YOLO('datasets/yolov8n-MobileNetV3/train3/weights/512best.engine')
#rt_model = YOLO('datasets/yolov8n-ShuffleNetV2-SlimNeck/train62/weights/512best.engine')
trt_model = YOLO('datasets/yolov8n-ShuffleNetV2-SlimNeck/train74/weights/512best.engine')

# Run inference
#results = trt_model('ultralytics/assets/bus.jpg',imgsz=(512,384), device=0)
results = trt_model(source='0',imgsz=(512,512), device=0)
#results = trt_model('video/nrt.mp4',imgsz=(512,512), device=0,show=True)