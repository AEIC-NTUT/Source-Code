from ultralytics import YOLO

#model = YOLO("datasets/yolov8n/train15/weights/best.pt")

#model = YOLO("datasets/yolov8n-ShuffleNetV2-SlimNeck/train62/weights/best.pt")

#model = YOLO("datasets/yolov8n-MobileNetV3/train3/weights/best.pt")

#model = YOLO("datasets/yolov8n-GhostNetV1-2/train2/weights/best.pt")

model = YOLO("datasets/yolov8n-ShuffleNetV2-SlimNeck/train74/weights/best.pt")


results = model('video/nrt.mp4',imgsz=(512,512), device=0,show=True,conf=0.9,iou=0.1)

#results = model('ultralytics/assets/bus.jpg',imgsz=(512,512), device=0)
#results = model(source='0',imgsz=(512,512), device=0)